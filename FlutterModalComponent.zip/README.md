# Flutter Modal Component

This is a reusable modal (dialog) component for Flutter apps.

## Files

- `main.dart`: Main app file with modal usage example.
- `custom_modal.dart`: Custom modal widget.

## Features

- Rounded corners
- Title and content text
- Dismissable by button
- Can be reused anywhere in your app

## How to Use

Call `showDialog()` and pass the `CustomModal` widget with title and content. See `main.dart` for example.
