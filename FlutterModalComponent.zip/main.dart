import 'package:flutter/material.dart';
import 'custom_modal.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Modal Demo',
      home: const ModalExample(),
    );
  }
}

class ModalExample extends StatelessWidget {
  const ModalExample({super.key});

  void _showCustomModal(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => const CustomModal(
        title: 'Hello!',
        content: 'This is a custom modal dialog.',
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Custom Modal Example')),
      body: Center(
        child: ElevatedButton(
          onPressed: () => _showCustomModal(context),
          child: const Text('Show Modal'),
        ),
      ),
    );
  }
}
